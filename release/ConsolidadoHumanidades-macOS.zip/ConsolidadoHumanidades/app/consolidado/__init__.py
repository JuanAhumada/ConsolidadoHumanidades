"""
Paquete consolidado: fusión de Excels de estudiantes.

Subpaquetes:
- config: JSON vivo + defaults
- core: pipeline y reglas
- storage: SQLite y marcas globales
- web: FastAPI (interfaz principal)
- gui: escritorio (legado)
"""

from consolidado.version import APP_VERSION as __version__

from consolidado.config.settings import (
    ARCHIVOS_FUENTE_REQUERIDOS,
    COLUMNAS_ALERTAS,
    COLUMNAS_BECAS,
    COLUMNAS_DATOS,
    COLUMNAS_PRIORIZADO,
    cargar_config,
    carpeta_excels,
    construir_columnas_salida,
    construir_grupos_encabezado,
    guardar_config,
    ruta_config,
)
from consolidado.core.alertas import (
    _aplicar_alertas,
    _cargar_alertas_cfg,
    procesar_archivo_alertas,
)
from consolidado.core.alertas_propias import (
    aplicar_alertas_propias,
    obtener_lista_alertas_propias_vista,
)
from consolidado.core.archivos import (
    _tipo_libro_desde_nombre,
    preparar_archivo,
    procesar_tabla_priorizados,
    procesar_tabla_priorizados_con_recuperacion,
    resumir_hoja_horario,
)
from consolidado.core.cli import main
from consolidado.core.columnas import (
    alinear_dataframe_salida,
    construir_mapa_columnas,
    formatear_dataframe_salida,
    renombrar_y_filtrar,
)
from consolidado.core.constants import (
    COL_DATOS_CONTACTO,
    COL_FECHA_NACIMIENTO,
    COL_FUNCIONARIO_BECA,
    COL_NOMBRE,
    COL_NUM_ALERTAS,
    COL_TELEFONO_CELULAR,
    COL_TIPOS_ALERTA,
    FILL_CALL_CENTER_EXCEL,
    FONT_MATERIA_REPETIDA,
    FORMATO_FECHA_DMY,
    FORMATO_FECHA_MDY,
    HOJA_LISTADO,
    MOTIVO_PRIORIZADO_PROPIO,
    SALIDA_COLUMNAS_LISTADO,
    TITULOS_EXCEL_FUENTE,
    _TIPOS_FUENTE_AUXILIARES,
    aplicar_config,
    columnas_materia_horario,
    es_columna_materia_horario,
    max_materias_en_dataframe,
)
from consolidado.core.documentos import (
    _unir_documentos_adicionales,
    procesar_documento_adicional,
)
from consolidado.core.excel_io import (
    abrir_archivo_en_sistema,
    elegir_cuatro_excels_en_explorador,
    elegir_guardar_consolidado,
    ejecutar_lectura_con_recuperacion,
    listar_excels_en_carpeta,
    resolver_ruta_salida_consolidado,
)
from consolidado.core.export import guardar_excel_consolidado
from consolidado.core.fusion import (
    deduplicar_por_nombre,
    filtrar_filas_con_nombre,
    filtrar_filas_con_telefono,
    filtrar_filas_consolidado,
    filtrar_filas_programa_excluido,
    filtrar_filas_programas_permitidos,
    fusionar_por_id,
)
from consolidado.core.normalizacion import (
    combinar_valores,
    formatear_fecha_nacimiento,
    normalizar_encabezado,
    normalizar_id,
    normalizar_telefono_celda,
    programa_es_permitido,
    programa_esta_excluido,
)
from consolidado.core.pipeline import ejecutar_consolidado
from consolidado.core.priorizados import (
    aplicar_priorizados_propios,
    buscar_estudiantes_en_fuentes,
    obtener_lista_priorizados_vista,
)
from consolidado.core.repetidas import (
    _cargar_materias_repetidas_cfg,
    _materia_es_repetida,
    procesar_materias_repetidas,
)

__all__ = [
    "ARCHIVOS_FUENTE_REQUERIDOS",
    "COL_DATOS_CONTACTO",
    "COL_FECHA_NACIMIENTO",
    "COL_FUNCIONARIO_BECA",
    "COL_NOMBRE",
    "COL_NUM_ALERTAS",
    "COL_TELEFONO_CELULAR",
    "COL_TIPOS_ALERTA",
    "COLUMNAS_ALERTAS",
    "COLUMNAS_BECAS",
    "COLUMNAS_DATOS",
    "COLUMNAS_PRIORIZADO",
    "FILL_CALL_CENTER_EXCEL",
    "FONT_MATERIA_REPETIDA",
    "FORMATO_FECHA_DMY",
    "FORMATO_FECHA_MDY",
    "HOJA_LISTADO",
    "MOTIVO_PRIORIZADO_PROPIO",
    "SALIDA_COLUMNAS_LISTADO",
    "TITULOS_EXCEL_FUENTE",
    "_TIPOS_FUENTE_AUXILIARES",
    "_aplicar_alertas",
    "_cargar_alertas_cfg",
    "_cargar_materias_repetidas_cfg",
    "_materia_es_repetida",
    "_tipo_libro_desde_nombre",
    "_unir_documentos_adicionales",
    "abrir_archivo_en_sistema",
    "alinear_dataframe_salida",
    "aplicar_config",
    "aplicar_alertas_propias",
    "aplicar_priorizados_propios",
    "buscar_estudiantes_en_fuentes",
    "cargar_config",
    "carpeta_excels",
    "columnas_materia_horario",
    "combinar_valores",
    "construir_columnas_salida",
    "construir_grupos_encabezado",
    "construir_mapa_columnas",
    "deduplicar_por_nombre",
    "ejecutar_consolidado",
    "ejecutar_lectura_con_recuperacion",
    "elegir_cuatro_excels_en_explorador",
    "elegir_guardar_consolidado",
    "es_columna_materia_horario",
    "filtrar_filas_con_nombre",
    "filtrar_filas_con_telefono",
    "filtrar_filas_consolidado",
    "filtrar_filas_programa_excluido",
    "filtrar_filas_programas_permitidos",
    "formatear_dataframe_salida",
    "formatear_fecha_nacimiento",
    "fusionar_por_id",
    "guardar_config",
    "guardar_excel_consolidado",
    "listar_excels_en_carpeta",
    "main",
    "max_materias_en_dataframe",
    "normalizar_encabezado",
    "normalizar_id",
    "normalizar_telefono_celda",
    "obtener_lista_alertas_propias_vista",
    "obtener_lista_priorizados_vista",
    "preparar_archivo",
    "procesar_archivo_alertas",
    "procesar_documento_adicional",
    "procesar_materias_repetidas",
    "procesar_tabla_priorizados",
    "procesar_tabla_priorizados_con_recuperacion",
    "programa_es_permitido",
    "programa_esta_excluido",
    "renombrar_y_filtrar",
    "resolver_ruta_salida_consolidado",
    "resumir_hoja_horario",
    "ruta_config",
]
