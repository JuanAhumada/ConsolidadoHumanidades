"""
Seguimiento: estudiantes con nivel de prioridad ≥ 1.

Categorías: General (puntaje total), componentes de puntaje y Alertas.
El listado web muestra nombre + puntaje; el check es global (contactados).
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from consolidado.core.colores_programa import color_programa, estilo_color
from consolidado.core.charts import partir_items
from consolidado.core.constants import (
    COL_NUM_ALERTA_FINAL,
    COL_NUM_ALERTA_INICIAL,
    COL_TIPO_ALERTA_FINAL,
    COL_TIPO_ALERTA_INICIAL,
)
from consolidado.core.prioridad import fmt_pts
from consolidado.core.normalizacion import _es_nulo, _es_valor_true, es_estudiante_activo, normalizar_id
from consolidado.paths import PROJECT_ROOT
from consolidado.storage.alertas_fuente import partir_tipos_alerta
from consolidado.storage.alertas_propias import cargar_alertas_propias
from consolidado.storage.contactados import cargar_ids_contactados
from consolidado.storage.db import cargar_dataframe_version, conexion, inicializar_db, ultima_version
from consolidado.storage.ediciones import cargar_ediciones, overlay_ediciones_fila
from consolidado.storage.notas import resumen_notas

CATEGORIAS_SEGUIMIENTO: tuple[dict[str, str], ...] = (
    {"id": "general", "titulo": "General", "columna": "Puntaje prioridad", "grupo": "general"},
    {"id": "beca", "titulo": "Beca", "columna": "Ptje Beca", "grupo": "puntaje"},
    {"id": "priorizado", "titulo": "Priorizado", "columna": "Ptje Priorizado", "grupo": "puntaje"},
    {"id": "repitiendo", "titulo": "Repitiendo", "columna": "Ptje Repitiendo", "grupo": "puntaje"},
    {"id": "reintegro", "titulo": "Reintegro", "columna": "Ptje Reintegro", "grupo": "puntaje"},
    {"id": "propio", "titulo": "Propio", "columna": "Ptje Propio", "grupo": "puntaje"},
    {"id": "activacion", "titulo": "Activación", "columna": "Ptje Activacion", "grupo": "puntaje"},
    {"id": "ruta", "titulo": "Ruta", "columna": "Ptje Ruta", "grupo": "puntaje"},
    {"id": "alertas", "titulo": "Alertas", "columna": "", "grupo": "alertas"},
    {"id": "notas", "titulo": "Notas", "columna": "", "grupo": "notas"},
)

def _numero(val: Any) -> float:
    if _es_nulo(val):
        return 0.0
    if isinstance(val, bool):
        return 1.0 if val else 0.0
    if isinstance(val, (int, float)):
        return float(val)
    texto = str(val).strip().replace(",", ".")
    try:
        return float(texto)
    except ValueError:
        return 0.0


def _entero(val: Any) -> int:
    return int(_numero(val))


def _texto(val: Any) -> str:
    if _es_nulo(val):
        return ""
    if isinstance(val, bool):
        return "Sí" if val else ""
    texto = str(val).strip()
    if texto.lower() in {"none", "nan", "null", "nat", "—"}:
        return ""
    return texto


def categoria_seguimiento(cat_id: str) -> dict[str, str]:
    clave = (cat_id or "general").strip().lower()
    for cat in CATEGORIAS_SEGUIMIENTO:
        if cat["id"] == clave:
            return cat
    return dict(CATEGORIAS_SEGUIMIENTO[0])


def _fila_base(fila: dict[str, Any], ids_contactados: set[str]) -> dict[str, Any] | None:
    ident = normalizar_id(fila.get("Identificación"))
    if not ident:
        return None
    if not es_estudiante_activo(fila.get("Activos")):
        return None
    nivel = _entero(fila.get("Nivel prioridad"))
    if nivel < 1:
        return None
    programa = _texto(fila.get("Programa"))
    color = color_programa(programa)
    puntaje = _numero(fila.get("Puntaje prioridad"))
    alertas_ini = partir_tipos_alerta(fila.get(COL_TIPO_ALERTA_INICIAL))
    alertas_fin = partir_tipos_alerta(fila.get(COL_TIPO_ALERTA_FINAL))
    alerta_propia = _texto(fila.get("Alerta Propia")) or _texto(fila.get("Detalle Propio"))
    n_alertas = (
        len(alertas_ini)
        + len(alertas_fin)
        + (1 if alerta_propia else 0)
        or _entero(fila.get(COL_NUM_ALERTA_INICIAL))
        + _entero(fila.get(COL_NUM_ALERTA_FINAL))
    )
    return {
        "identificacion": ident,
        "nombre": _texto(fila.get("Nombre y apellidos")) or ident,
        "programa": programa,
        "nivel": nivel,
        "puntaje": puntaje,
        "ptje_beca": _numero(fila.get("Ptje Beca")),
        "ptje_priorizado": _numero(fila.get("Ptje Priorizado")),
        "ptje_repitiendo": _numero(fila.get("Ptje Repitiendo")),
        "ptje_reintegro": _numero(fila.get("Ptje Reintegro")),
        "ptje_propio": _numero(fila.get("Ptje Propio")),
        "ptje_activacion": _numero(fila.get("Ptje Activacion")),
        "ptje_ruta": _numero(fila.get("Ptje Ruta")),
        "puntaje_txt": fmt_pts(puntaje),
        "priorizado": _es_valor_true(fila.get("Priorizado")),
        "motivo": _texto(fila.get("Motivo Prio.")),
        "motivos_prio": partir_items(_texto(fila.get("Motivo Prio."))),
        "detalle_gprio": _texto(fila.get("Detalle GPrio.")),
        "detalle_prioridad": _texto(fila.get("Detalle prioridad")),
        "telefono": _texto(fila.get("Teléfono celular")),
        "correo_institucional": _texto(fila.get("Correo institucional")),
        "correo_personal": _texto(fila.get("Correo personal")),
        "periodo_ingreso": _texto(fila.get("Periodo ingreso")),
        "periodo_actual": _texto(fila.get("Periodo actual")),
        "reintegros": _texto(fila.get("Reintegros")),
        "tipo_beca": _texto(fila.get("Tipo de beca o crédito")),
        "tipos_beca": partir_items(_texto(fila.get("Tipo de beca o crédito"))),
        "total_beca": _texto(fila.get("Total beca")),
        "funcionario_beca": _texto(fila.get("Funcionario que tiene a cargo la beca")),
        "repitiendo": _es_valor_true(fila.get("Repitiendo")),
        "alertas_inicial": alertas_ini,
        "alertas_final": alertas_fin,
        "alerta_propia": alerta_propia,
        "num_alertas": n_alertas,
        "n_notas": 0,
        "ultima_nota": "",
        "contactado": ident in ids_contactados,
        "color": color,
        "estilo": estilo_color(color),
    }


def _puntaje_categoria(item: dict[str, Any], cat: dict[str, str]) -> float:
    cid = cat["id"]
    if cid == "general":
        return float(item["puntaje"])
    if cid == "alertas":
        return float(item["num_alertas"])
    if cid == "notas":
        return float(item.get("n_notas") or 0)
    mapa = {
        "beca": "ptje_beca",
        "priorizado": "ptje_priorizado",
        "repitiendo": "ptje_repitiendo",
        "reintegro": "ptje_reintegro",
        "propio": "ptje_propio",
        "activacion": "ptje_activacion",
        "ruta": "ptje_ruta",
    }
    return float(item.get(mapa.get(cid, "puntaje"), 0) or 0)


def _entra_en_categoria(item: dict[str, Any], cat: dict[str, str]) -> bool:
    cid = cat["id"]
    if cid == "general":
        return True
    if cid == "alertas":
        return item["num_alertas"] > 0 or bool(item["alerta_propia"])
    if cid == "notas":
        return int(item.get("n_notas") or 0) > 0
    if cid == "priorizado":
        return item["ptje_priorizado"] > 0 or item["priorizado"]
    return _puntaje_categoria(item, cat) > 0


def _tiene_tipo(partes: list[str], seleccion: list[str]) -> bool:
    if not seleccion:
        return True
    claves = {s.casefold() for s in seleccion if s}
    return any(p.casefold() in claves for p in partes)


def _opciones_tipo(filas: list[dict[str, Any]], campo: str) -> list[str]:
    vistos: list[str] = []
    for f in filas:
        for parte in f.get(campo) or []:
            if parte and parte not in vistos:
                vistos.append(parte)
    return sorted(vistos, key=lambda s: s.casefold())


_UNIVERSO_CACHE: dict[str, Any] = {"clave": None, "items": None}


def _stamp_universo(base: Path, version_id: int) -> tuple:
    inicializar_db(base)
    with conexion(base) as conn:
        n_ed = conn.execute("SELECT COUNT(*) AS n FROM estudiante_ediciones").fetchone()["n"]
        n_notas = conn.execute("SELECT COUNT(*) AS n FROM seguimiento_notas").fetchone()["n"]
        n_al = conn.execute("SELECT COUNT(*) AS n FROM alertas_propias").fetchone()["n"]
    return (int(version_id), int(n_ed or 0), int(n_notas or 0), int(n_al or 0))


def _construir_universo(
    df,
    *,
    propias: dict[str, Any],
    notas: dict[str, Any],
    ediciones: dict[str, Any],
) -> list[dict[str, Any]]:
    universo: list[dict[str, Any]] = []
    ids_vacio: set[str] = set()
    for fila in df.iter_rows(named=True):
        fila = overlay_ediciones_fila(fila, ediciones)
        item = _fila_base(fila, ids_vacio)
        if item is None:
            continue
        propia = propias.get(item["identificacion"])
        if propia and not item["alerta_propia"]:
            item["alerta_propia"] = _texto(propia.get("detalle"))
            item["num_alertas"] = int(item["num_alertas"]) + 1
        res = notas.get(item["identificacion"]) or {}
        item["n_notas"] = int(res.get("n") or 0)
        item["ultima_nota"] = str(res.get("ultima") or "")
        universo.append(item)
    return universo


def listar_seguimiento(
    *,
    cat_id: str = "general",
    vista: str = "pendientes",
    programas: list[str] | None = None,
    tipos_beca: list[str] | None = None,
    tipos_prio: list[str] | None = None,
    base: Path | None = None,
) -> dict[str, Any]:
    """Estudiantes de la última versión con nivel ≥ 1, filtrados por categoría."""
    base = base or PROJECT_ROOT
    cat = categoria_seguimiento(cat_id)
    programas_sel = [p.strip() for p in (programas or []) if p and str(p).strip()]
    becas_sel = [t.strip() for t in (tipos_beca or []) if t and str(t).strip()]
    motivos_sel = [t.strip() for t in (tipos_prio or []) if t and str(t).strip()]
    vacio = {
        "categoria": cat,
        "categorias": [
            {**c, "n": 0, "n_pendientes": 0} for c in CATEGORIAS_SEGUIMIENTO
        ],
        "filas": [],
        "total": 0,
        "visibles": 0,
        "vista": vista,
        "meta": None,
        "programas": [],
        "programas_sel": [],
        "tipos_beca": [],
        "tipos_beca_sel": [],
        "tipos_prio": [],
        "tipos_prio_sel": [],
    }
    ult = ultima_version(base)
    if ult is None:
        return vacio

    df = cargar_dataframe_version(int(ult["id"]), base)
    ids_contactados = cargar_ids_contactados(base)
    clave = _stamp_universo(base, int(ult["id"]))
    if _UNIVERSO_CACHE.get("clave") != clave or _UNIVERSO_CACHE.get("items") is None:
        propias = {
            normalizar_id(a.get("identificacion")): a
            for a in cargar_alertas_propias(base)
            if normalizar_id(a.get("identificacion"))
        }
        notas = resumen_notas(base)
        ediciones = cargar_ediciones(base)
        _UNIVERSO_CACHE["clave"] = clave
        _UNIVERSO_CACHE["items"] = _construir_universo(
            df, propias=propias, notas=notas, ediciones=ediciones
        )
    universo_src = _UNIVERSO_CACHE["items"]

    programas_opciones = sorted({f["programa"] for f in universo_src if f["programa"]})
    programas_sel = [p for p in programas_sel if p in programas_opciones]
    if programas_sel:
        universo_f = [f for f in universo_src if f["programa"] in programas_sel]
    else:
        universo_f = universo_src

    cats_out: list[dict[str, Any]] = []
    for c in CATEGORIAS_SEGUIMIENTO:
        miembros = [f for f in universo_f if _entra_en_categoria(f, c)]
        cats_out.append(
            {
                **c,
                "n": len(miembros),
                "n_pendientes": sum(
                    1 for f in miembros if f["identificacion"] not in ids_contactados
                ),
            }
        )

    filtradas = [f for f in universo_f if _entra_en_categoria(f, cat)]
    tipos_beca_opciones = _opciones_tipo(filtradas, "tipos_beca")
    tipos_prio_opciones = _opciones_tipo(filtradas, "motivos_prio")
    becas_sel = [t for t in becas_sel if t in tipos_beca_opciones]
    motivos_sel = [t for t in motivos_sel if t in tipos_prio_opciones]
    cid = cat["id"]
    if cid in {"general", "beca"} and becas_sel:
        filtradas = [f for f in filtradas if _tiene_tipo(f.get("tipos_beca") or [], becas_sel)]
    if cid in {"general", "priorizado"} and motivos_sel:
        filtradas = [f for f in filtradas if _tiene_tipo(f.get("motivos_prio") or [], motivos_sel)]
    filtradas.sort(
        key=lambda f: (
            -_puntaje_categoria(f, cat),
            -float(f["puntaje"]),
            -int(f["nivel"]),
            f["nombre"].casefold(),
        )
    )
    tope = max((_puntaje_categoria(f, cat) for f in filtradas), default=1.0) or 1.0
    pintadas: list[dict[str, Any]] = []
    for f in filtradas:
        valor = _puntaje_categoria(f, cat)
        pintadas.append(
            {
                **f,
                "contactado": f["identificacion"] in ids_contactados,
                "puntaje_lista": valor,
                "puntaje_txt": fmt_pts(valor),
                "pct": round(min(valor / tope, 1.0) * 100) if tope else 0,
            }
        )

    if vista != "todos":
        visibles = [f for f in pintadas if not f["contactado"]]
    else:
        visibles = pintadas

    return {
        "categoria": cat,
        "categorias": cats_out,
        "filas": visibles,
        "total": len(pintadas),
        "visibles": len(visibles),
        "vista": "todos" if vista == "todos" else "pendientes",
        "meta": ult,
        "programas": programas_opciones,
        "programas_sel": programas_sel,
        "tipos_beca": tipos_beca_opciones,
        "tipos_beca_sel": becas_sel,
        "tipos_prio": tipos_prio_opciones,
        "tipos_prio_sel": motivos_sel,
    }
