"""
Normalización de celdas: id, teléfonos, fechas, programas, periodo.

formatear_periodo_cod: 20261 → 2026-1 (año 1990–2099, último dígito 1 o 2).
normalizar_id quita espacios y decimales de Excel.
"""
from __future__ import annotations

import re
from datetime import date, datetime, timedelta

import polars as pl

from consolidado.core.constants import (
    FORMATO_FECHA_DMY,
    FORMATO_FECHA_MDY,
    _CARACTERES_TILDE,
    _EXCEL_EPOCH,
    _MESES_ES,
    _PROGRAMAS_EXCLUIDOS_RUNTIME,
    _PROGRAMAS_PERMITIDOS_RUNTIME,
    _REEMPLAZO_ACENTOS,
    aplicar_config,
)
def _es_nulo(val) -> bool:
    if val is None:
        return True
    if isinstance(val, float):
        return val != val
    return False

def _anio_completo(anio: int) -> int:
    if anio < 100:
        return 2000 + anio if anio < 50 else 1900 + anio
    return anio

def _fecha_a_texto_salida(d: date) -> str:
    """Formato MMMM-DD-YYYY (mes en español, p. ej. Mayo-20-2003)."""
    mes = _MESES_ES[d.month - 1].capitalize()
    return f"{mes}-{d.day:02d}-{d.year:04d}"

def _fecha_a_texto_dmy(d: date) -> str:
    return _fecha_a_texto_salida(d)

def _es_serial_excel_fecha(val) -> bool:
    if isinstance(val, bool):
        return False
    if isinstance(val, (int, float)) and not _es_nulo(val):
        n = float(val)
        return 1000 < n < 120000
    return False

def _serial_excel_a_fecha(serial: float) -> date | None:
    try:
        return _EXCEL_EPOCH + timedelta(days=int(serial))
    except (OverflowError, ValueError):
        return None

def _parsear_fecha_texto(texto: str, orden: str) -> date | None:
    s = texto.strip()
    if not s or s.lower() in ("nan", "nat", "none"):
        return None
    if " " in s:
        s = s.split()[0]
    if "T" in s and len(s) > 10:
        s = s.split("T")[0]

    iso = re.match(r"^(\d{4})-(\d{2})-(\d{2})", s)
    if iso:
        try:
            return date(int(iso.group(1)), int(iso.group(2)), int(iso.group(3)))
        except ValueError:
            pass

    for sep in ("/", "-", "."):
        if sep not in s:
            continue
        partes = re.split(r"[/\-.]", s)
        if len(partes) != 3:
            continue
        try:
            p0, p1, p2 = (int(x) for x in partes)
        except ValueError:
            continue
        anio = _anio_completo(p2)
        if orden == FORMATO_FECHA_DMY:
            dia, mes = p0, p1
        else:
            mes, dia = p0, p1
        try:
            return date(anio, mes, dia)
        except ValueError:
            continue
    return None

def formatear_fecha_nacimiento(val, orden_origen: str = FORMATO_FECHA_DMY) -> str | None:
    """Normaliza a texto MMMM-DD-YYYY (mes en español)."""
    if _es_nulo(val):
        return None
    if isinstance(val, datetime):
        return _fecha_a_texto_dmy(val.date())
    if isinstance(val, date):
        return _fecha_a_texto_dmy(val)
    if hasattr(val, "date") and callable(getattr(val, "date", None)):
        try:
            return _fecha_a_texto_dmy(val.date())
        except (TypeError, ValueError):
            pass
    if _es_serial_excel_fecha(val):
        d = _serial_excel_a_fecha(float(val))
        if d:
            return _fecha_a_texto_dmy(d)
    texto = str(val).strip()
    if not texto or texto.lower() in ("nan", "nat"):
        return None
    d = _parsear_fecha_texto(texto, orden_origen)
    if d:
        return _fecha_a_texto_dmy(d)
    otro = FORMATO_FECHA_MDY if orden_origen == FORMATO_FECHA_DMY else FORMATO_FECHA_DMY
    d = _parsear_fecha_texto(texto, otro)
    if d:
        return _fecha_a_texto_dmy(d)
    return texto

def _orden_fecha_por_tipo_libro(tipo: str) -> str:
    return FORMATO_FECHA_MDY if tipo == "bd12" else FORMATO_FECHA_DMY

def normalizar_encabezado(col: str) -> str:
    if col is None or _es_nulo(col):
        return ""
    s = str(col).strip().lower().translate(_REEMPLAZO_ACENTOS)
    s = s.replace("_", " ")
    s = re.sub(r"\s+", " ", s)
    return s

def programa_esta_excluido(val) -> bool:
    if _es_nulo(val):
        return False
    if not _PROGRAMAS_EXCLUIDOS_RUNTIME:
        aplicar_config()
    norm = normalizar_encabezado(str(val))
    if norm in _PROGRAMAS_EXCLUIDOS_RUNTIME:
        return True
    for excl in _PROGRAMAS_EXCLUIDOS_RUNTIME:
        if excl and excl in norm:
            return True
    return False

def programa_es_permitido(val) -> bool:
    if _es_nulo(val):
        return False
    if not _PROGRAMAS_PERMITIDOS_RUNTIME:
        aplicar_config()
    partes = [p.strip() for p in str(val).split("|") if p.strip()]
    if not partes:
        return False
    for parte in partes:
        if programa_esta_excluido(parte):
            continue
        if normalizar_encabezado(parte) in _PROGRAMAS_PERMITIDOS_RUNTIME:
            return True
    return False

def _es_valor_true(val) -> bool:
    if _es_nulo(val):
        return False
    if isinstance(val, bool):
        return val
    if isinstance(val, (int, float)):
        return val == 1
    return str(val).strip().lower() in ("true", "verdadero", "si", "sí", "1")


def es_estudiante_activo(val) -> bool:
    """True si no está marcado como graduado/inactivo. Sin valor se asume activo."""
    if _es_nulo(val):
        return True
    if isinstance(val, bool):
        return val
    if isinstance(val, (int, float)):
        return val != 0
    texto = str(val).strip().lower()
    if texto in {"false", "0", "no", "n", "f", "inactivo"}:
        return False
    return True

def normalizar_id(val) -> str:
    if _es_nulo(val):
        return ""
    # Enteros de Excel sin decimales molestos
    if isinstance(val, float) and val == int(val):
        val = int(val)
    s = str(val).strip()
    s = re.sub(r"\s+", "", s)
    return s


PREFIJO_CLAVE_NOMBRE = "n:"


def periodo_academico_nota(fecha: date | datetime | None = None) -> str:
    """Dic–mayo → YYYY-1 (diciembre cuenta el año siguiente); jun–nov → YYYY-2."""
    if fecha is None:
        fecha = date.today()
    if isinstance(fecha, datetime):
        fecha = fecha.date()
    anio, mes = fecha.year, fecha.month
    if mes == 12:
        return f"{anio + 1}-1"
    if mes <= 5:
        return f"{anio}-1"
    return f"{anio}-2"


def periodo_academico_de_texto(creado_en: str | None) -> str | None:
    """Periodo de una anotación a partir de su fecha ISO."""
    texto = str(creado_en or "").strip()
    if not texto:
        return None
    try:
        dt = datetime.fromisoformat(texto.replace("Z", ""))
        return periodo_academico_nota(dt)
    except ValueError:
        pass
    if len(texto) >= 10:
        try:
            return periodo_academico_nota(date.fromisoformat(texto[:10]))
        except ValueError:
            return None
    return None


def clave_fusion_estudiante(identificacion=None, nombre=None) -> str:
    """Llave de cruce: identificación si existe; si no, nombre único con prefijo n:."""
    nid = clave_cruce_identificacion(identificacion)
    if nid:
        return nid
    nkey = _clave_nombre_unico(nombre)
    if nkey:
        return f"{PREFIJO_CLAVE_NOMBRE}{nkey}"
    return ""


def clave_cruce_identificacion(val) -> str:
    """Misma clave que Identificación al cruzar Excel adicionales.

    Quita espacios, decimales de Excel y separadores de miles (1.234.567 → 1234567)
    para que la llave foránea coincida con la identificación del consolidado.
    """
    base = _entero_o_texto(val)
    s = normalizar_id(base if base is not None else val)
    if not s:
        return ""
    compacto = re.sub(r"[.\-\s/]", "", s)
    if compacto.isdigit():
        return compacto
    return s


_RE_PERIODO_ETIQUETA = re.compile(r"^(19|20)\d{2}\s*[-–/\s]\s*([12])$")
_ANIO_PERIODO_MIN = 1990
_ANIO_PERIODO_MAX = 2099


def formatear_periodo_cod(val) -> str | None:
    """COD_PERIODO / COD_PENSUM de 5 dígitos (YYYY + 1|2) → 'YYYY-N'."""
    if _es_nulo(val):
        return None
    if isinstance(val, bool):
        return None
    if isinstance(val, float) and val == int(val):
        val = int(val)
    texto = str(val).strip()
    if not texto or texto.lower() in ("nan", "none", "-", "—"):
        return None
    m = _RE_PERIODO_ETIQUETA.match(texto)
    if m:
        anio = int(texto[:4])
        if _ANIO_PERIODO_MIN <= anio <= _ANIO_PERIODO_MAX:
            return f"{anio}-{m.group(2)}"
    digitos = re.sub(r"\D", "", texto)
    if len(digitos) == 5:
        anio = int(digitos[:4])
        per = digitos[4]
        if _ANIO_PERIODO_MIN <= anio <= _ANIO_PERIODO_MAX and per in "12":
            return f"{anio}-{per}"
    return None


def _clave_periodo(periodo: str) -> tuple[int, int] | None:
    m = re.match(r"^(\d{4})-([12])$", periodo or "")
    if not m:
        return None
    return int(m.group(1)), int(m.group(2))


_MESES_ORDEN = {
    str(nombre).casefold().translate(_REEMPLAZO_ACENTOS): i + 1
    for i, nombre in enumerate(_MESES_ES)
}
_RE_FECHA_MES_NOMBRE = re.compile(
    r"^([A-Za-zÁÉÍÓÚáéíóúüÜñÑ]+)\s*[-/.\s]\s*(\d{1,2})\s*[-/.\s]\s*(\d{2,4})$"
)
_RE_FECHA_DIA_MES = re.compile(
    r"^(\d{1,2})\s*[-/.\s]\s*([A-Za-zÁÉÍÓÚáéíóúüÜñÑ]+)\s*[-/.\s]\s*(\d{2,4})$"
)


def _parsear_fecha_etiqueta(texto: str) -> date | None:
    s = str(texto or "").strip()
    if not s:
        return None
    d = _parsear_fecha_texto(s, FORMATO_FECHA_DMY) or _parsear_fecha_texto(s, FORMATO_FECHA_MDY)
    if d:
        return d
    m = _RE_FECHA_MES_NOMBRE.match(s)
    if m:
        mes = _MESES_ORDEN.get(m.group(1).casefold().translate(_REEMPLAZO_ACENTOS))
        if mes:
            try:
                return date(_anio_completo(int(m.group(3))), mes, int(m.group(2)))
            except ValueError:
                return None
    m = _RE_FECHA_DIA_MES.match(s)
    if m:
        mes = _MESES_ORDEN.get(m.group(2).casefold().translate(_REEMPLAZO_ACENTOS))
        if mes:
            try:
                return date(_anio_completo(int(m.group(3))), mes, int(m.group(1)))
            except ValueError:
                return None
    return None


def clave_orden_etiqueta(texto: str) -> tuple:
    """Orden de eje X: fechas y periodos cronológicos, luego número, luego A–Z."""
    s = str(texto or "").strip()
    d = _parsear_fecha_etiqueta(s)
    if d:
        return (0, d.toordinal(), s.casefold())
    periodo = formatear_periodo_cod(s)
    if periodo:
        clave = _clave_periodo(periodo)
        if clave:
            return (1, clave[0] * 2 + clave[1], s.casefold())
    compacto = s.replace(" ", "").replace(",", ".")
    try:
        return (2, float(compacto), s.casefold())
    except ValueError:
        pass
    return (3, 0.0, s.casefold())


def periodo_mas_reciente(valores: list) -> str | None:
    """Elige el periodo YYYY-N más reciente entre varios orígenes."""
    mejores: list[tuple[tuple[int, int], str]] = []
    for v in valores:
        f = formatear_periodo_cod(v)
        if not f:
            continue
        clave = _clave_periodo(f)
        if clave:
            mejores.append((clave, f))
    if not mejores:
        return None
    return max(mejores, key=lambda item: item[0])[1]

def _mapa_norm_a_real(columns: list[str]) -> dict[str, str]:
    return {normalizar_encabezado(c): c for c in columns}

def _str_celda(v) -> str:
    if _es_nulo(v):
        return ""
    s = str(v).strip()
    return "" if s.lower() == "nan" else s

def _nombre_valido(val) -> bool:
    if _es_nulo(val):
        return False
    s = str(val).strip()
    if not s or s.lower() in ("nan", "none", "nat", "-", "—"):
        return False
    return True

def _clave_nombre_unico(val) -> str:
    """Clave para comparar nombres (sin acentos, minúsculas, espacios normalizados)."""
    if not _nombre_valido(val):
        return ""
    s = str(val).strip().lower().translate(_REEMPLAZO_ACENTOS)
    return re.sub(r"\s+", " ", s)

def _telefono_presente(val) -> bool:
    return bool(normalizar_telefono_celda(val))

def _es_valor_vacio(val) -> bool:
    if _es_nulo(val):
        return True
    return str(val).strip() == ""

def _cuenta_tildes(texto: str) -> int:
    return sum(1 for c in texto if c in _CARACTERES_TILDE)

def _preferir_nombre_con_tildes(nuevo: str, actual: str) -> bool:
    t_n = _cuenta_tildes(nuevo)
    t_a = _cuenta_tildes(actual)
    if t_n != t_a:
        return t_n > t_a
    return len(nuevo) > len(actual)

def combinar_valores(valores: list, separador: str = " | ") -> str:
    vals: list[str] = []
    for v in valores:
        if _es_nulo(v):
            continue
        s = str(v).strip()
        if s and s not in vals:
            vals.append(s)
    if not vals:
        return ""
    if len(vals) == 1:
        return vals[0]
    return separador.join(vals)


def parsear_monto_beca(val) -> float | None:
    """Convierte un valor de beca (número o texto con $ y separadores) a float."""
    if _es_nulo(val):
        return None
    if isinstance(val, (int, float)) and not isinstance(val, bool):
        return float(val)
    texto = re.sub(r"[^\d.,]", "", str(val).strip())
    if not texto:
        return None
    if "," in texto and "." in texto:
        if texto.rfind(",") > texto.rfind("."):
            texto = texto.replace(".", "").replace(",", ".")
        else:
            texto = texto.replace(",", "")
    elif "," in texto:
        partes = texto.split(",")
        texto = partes[0].replace(".", "") + "." + partes[-1] if len(partes) > 1 else texto.replace(",", ".")
    else:
        texto = texto.replace(".", "") if texto.count(".") > 1 else texto
    try:
        return float(texto)
    except ValueError:
        return None


def sumar_montos_beca(valores: list) -> int | float | None:
    """Suma los montos de varias becas del mismo estudiante."""
    total = 0.0
    encontrado = False
    for v in valores:
        monto = parsear_monto_beca(v)
        if monto is None:
            continue
        total += monto
        encontrado = True
    if not encontrado:
        return None
    return int(total) if total == int(total) else total


def formatear_monto_beca_vista(val) -> str | None:
    """Muestra un monto de beca como '$ 1.234.567' (puntos de miles)."""
    monto = parsear_monto_beca(val)
    if monto is None:
        return None
    negativo = monto < 0
    monto = abs(monto)
    entero = int(monto)
    frac = round(monto - entero, 2)
    cuerpo = f"{entero:,}".replace(",", ".")
    if frac:
        centavos = f"{frac:.2f}".split(".")[1]
        cuerpo = f"{cuerpo},{centavos}"
    prefijo = "-$ " if negativo else "$ "
    return f"{prefijo}{cuerpo}"

def _digitos_a_entero_str(digits: str) -> str | None:
    if not digits:
        return None
    try:
        return str(int(digits))
    except ValueError:
        return digits

def normalizar_telefono_celda(val) -> str | None:
    """Uno o varios teléfonos como enteros; varios separados por coma."""
    if _es_nulo(val):
        return None
    texto = str(val).strip()
    if not texto or texto.lower() == "nan":
        return None
    partes = re.split(r"[/|,]+|\s*\|\s*", texto)
    vistos: list[str] = []
    for parte in partes:
        p = parte.strip()
        if not p:
            continue
        if isinstance(p, float) and p == int(p):
            p = str(int(p))
        digits = re.sub(r"\D", "", p)
        entero = _digitos_a_entero_str(digits)
        if entero and entero not in vistos:
            vistos.append(entero)
    if not vistos:
        return None
    return ", ".join(vistos)

def _combinar_telefonos(valores: list) -> str:
    todos: list[str] = []
    for v in valores:
        norm = normalizar_telefono_celda(v)
        if not norm:
            continue
        for n in norm.split(", "):
            if n and n not in todos:
                todos.append(n)
    return ", ".join(todos)

def _entero_o_texto(val) -> str | None:
    if _es_nulo(val):
        return None
    if isinstance(val, float) and val == int(val):
        return str(int(val))
    if isinstance(val, int):
        return str(val)
    s = str(val).strip()
    if not s:
        return None
    digits = re.sub(r"\D", "", s)
    if digits and digits == re.sub(r"\s+", "", s):
        return digits
    return s

def _primero_no_vacio(valores: list):
    for v in valores:
        if _es_nulo(v):
            continue
        t = str(v).strip()
        if t:
            return v
    return None

def _es_funcionario_call_center(val) -> bool:
    if _es_nulo(val):
        return False
    return "call center" in str(val).strip().lower()


def es_responsable_beca_especial(val) -> bool:
    """Indica NO, 0 o Call Center (sin funcionario asignado con nombre propio)."""
    if _es_nulo(val):
        return False
    texto = str(val).strip().upper()
    if texto in ("0", "NO"):
        return True
    return _es_funcionario_call_center(val)


def combinar_funcionario_beca(valores: list) -> str | None:
    """
    Unifica responsables de varias becas del mismo estudiante.
    Si hay un nombre real, se conserva; si solo hay NO/0/Call Center y hay varios, queda CALL CENTER.
    """
    presentes: list[str] = []
    for v in valores:
        if _es_nulo(v):
            continue
        s = str(v).strip()
        if not s or s in presentes:
            continue
        presentes.append(s)
    if not presentes:
        return None
    for v in presentes:
        if not es_responsable_beca_especial(v):
            return v
    if len(presentes) > 1:
        return "CALL CENTER"
    return presentes[0]

