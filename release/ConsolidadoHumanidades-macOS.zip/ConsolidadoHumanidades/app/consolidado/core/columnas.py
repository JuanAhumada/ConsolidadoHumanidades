"""
Mapeo de encabezados de Excel a columnas canónicas de salida.

construir_mapa_columnas usa aliases de config. Periodo actual formatea
COD_PERIODO/COD_PENSUM (5 dígitos → YYYY-N); no use esa lógica para
Periodo ingreso.
"""
from __future__ import annotations

from contextlib import contextmanager
from typing import Iterator

import polars as pl

from consolidado.config.settings import COLUMNAS_PRIORIZADO
from consolidado.core.constants import (
    COL_FECHA_NACIMIENTO,
    COL_NOMBRE,
    COL_PERIODO_ACTUAL,
    COL_TELEFONO_CELULAR,
    FORMATO_FECHA_DMY,
    _ALIASES_RUNTIME,
    aplicar_config,
)
from consolidado.core.normalizacion import (
    _mapa_norm_a_real,
    formatear_fecha_nacimiento,
    formatear_periodo_cod,
    normalizar_encabezado,
    normalizar_id,
    normalizar_telefono_celda,
    _entero_o_texto,
)

_ALIASES_OVERRIDE: dict[str, list[str]] | None = None


def aliases_para_slot(slot: dict | None) -> dict[str, list[str]] | None:
    """Combina aliases globales con los del archivo (el mapeo del slot gana)."""
    if not slot:
        return None
    extra = slot.get("aliases")
    if not extra or not isinstance(extra, dict):
        return None
    if not _ALIASES_RUNTIME:
        aplicar_config()
    merged = {k: list(v) for k, v in _ALIASES_RUNTIME.items()}
    for canon, vals in extra.items():
        nombres = vals if isinstance(vals, list) else [vals]
        nombres = [str(x).strip() for x in nombres if str(x).strip()]
        if not nombres:
            continue
        previos = [a for a in merged.get(str(canon), []) if a not in nombres]
        merged[str(canon)] = nombres + previos
    return merged


@contextmanager
def usando_aliases(aliases: dict[str, list[str]] | None) -> Iterator[None]:
    global _ALIASES_OVERRIDE
    prev = _ALIASES_OVERRIDE
    _ALIASES_OVERRIDE = aliases
    try:
        yield
    finally:
        _ALIASES_OVERRIDE = prev


def _aliases_activos() -> dict[str, list[str]]:
    if _ALIASES_OVERRIDE:
        return _ALIASES_OVERRIDE
    if not _ALIASES_RUNTIME:
        aplicar_config()
    return _ALIASES_RUNTIME


def aliases_identificacion_efectivos(extra: list[str] | None = None) -> list[str]:
    base = [str(a) for a in (_aliases_activos().get("identificacion") or []) if str(a).strip()]
    for alias in extra or []:
        if alias not in base:
            base.append(alias)
    return base


def construir_mapa_columnas(columns: list[str]) -> dict[str, str]:
    """Devuelve canónico -> nombre real de columna en el DataFrame."""
    norm_to_real: dict[str, str] = {}
    for c in columns:
        k = normalizar_encabezado(c)
        if k and k not in norm_to_real:
            norm_to_real[k] = c

    resultado: dict[str, str] = {}
    for canon, aliases in _aliases_activos().items():
        for alias in aliases:
            key = normalizar_encabezado(alias)
            if key in norm_to_real:
                resultado[canon] = norm_to_real[key]
                break

    if "identificacion" not in resultado:
        for c in columns:
            n = normalizar_encabezado(c)
            if not n:
                continue
            if "docente" in n:
                continue
            if "identific" in n or n == "documento":
                resultado["identificacion"] = c
                break
    return resultado

def _expr_nombre_completo(df: pl.DataFrame, m: dict[str, str], nr: dict[str, str]) -> pl.Expr:
    if "nombre_estudiante" in m:
        col_nom = m["nombre_estudiante"]
        if "apellidos" in nr and "nombres" in nr and nr["nombres"] == col_nom:
            return (
                pl.concat_str(
                    [pl.col(nr["nombres"]).cast(pl.Utf8), pl.col(nr["apellidos"]).cast(pl.Utf8)],
                    separator=" ",
                )
                .str.replace_all(r"\s+", " ")
                .str.strip_chars()
                .alias("Nombre y apellidos")
            )
        return pl.col(col_nom).alias("Nombre y apellidos")
    if "nombres" in nr and "apellidos" in nr:
        return (
            pl.concat_str(
                [pl.col(nr["nombres"]).cast(pl.Utf8), pl.col(nr["apellidos"]).cast(pl.Utf8)],
                separator=" ",
            )
            .str.replace_all(r"\s+", " ")
            .str.strip_chars()
            .alias("Nombre y apellidos")
        )
    return pl.lit(None).alias("Nombre y apellidos")

def _expr_telefono_celular(df: pl.DataFrame, m: dict[str, str], nr: dict[str, str]) -> pl.Expr:
    if "telefono_celular" in m:
        col = m["telefono_celular"]
    else:
        col = None
        for clave in ("tel. celular", "celular", "tel cecular"):
            if clave in nr:
                col = nr[clave]
                break
    if col:
        return (
            pl.col(col)
            .map_elements(lambda v: normalizar_telefono_celda(v), return_dtype=pl.Utf8)
            .alias(COL_TELEFONO_CELULAR)
        )
    return pl.lit(None).alias(COL_TELEFONO_CELULAR)

def _expr_total_beca(df: pl.DataFrame, m: dict[str, str], nr: dict[str, str]) -> pl.Expr:
    """Valor monetario de la beca (columna TOTAL en hoja BECAS Y CRÉDITOS)."""
    if "total_beca" in m:
        return pl.col(m["total_beca"]).alias("Total beca")
    if "total" in nr:
        return pl.col(nr["total"]).alias("Total beca")
    col = _buscar_columna_por_aliases(list(df.columns), _aliases_activos().get("total_beca", []))
    if col:
        return pl.col(col).alias("Total beca")
    return pl.lit(None).alias("Total beca")


def _expr_funcionario_beca(df: pl.DataFrame, m: dict[str, str], nr: dict[str, str]) -> pl.Expr:
    if "funcionario_beca" in m:
        return pl.col(m["funcionario_beca"]).alias("Funcionario que tiene a cargo la beca")
    if "responsable" in nr:
        return pl.col(nr["responsable"]).alias("Funcionario que tiene a cargo la beca")
    return pl.lit(None).alias("Funcionario que tiene a cargo la beca")


def _expr_tipo_beca(df: pl.DataFrame, m: dict[str, str], nr: dict[str, str]) -> pl.Expr:
    if "nom concepto" in nr:
        nom = pl.col(nr["nom concepto"]).cast(pl.Utf8)
        if "tipo" in nr:
            tipo = pl.col(nr["tipo"]).cast(pl.Utf8)
            return (
                pl.when(tipo.is_not_null() & (tipo.str.strip_chars() != ""))
                .then(nom + pl.lit(" (") + tipo + pl.lit(")"))
                .otherwise(nom)
                .alias("Tipo de beca o crédito")
            )
        return nom.alias("Tipo de beca o crédito")
    if "tipo_beca_credito" in m:
        return pl.col(m["tipo_beca_credito"]).alias("Tipo de beca o crédito")
    return pl.lit(None).alias("Tipo de beca o crédito")

def _expr_fecha_nacimiento(df: pl.DataFrame, m: dict[str, str], orden: str) -> pl.Expr:
    if "fecha_nacimiento" not in m:
        return pl.lit(None).cast(pl.Utf8).alias(COL_FECHA_NACIMIENTO)
    return (
        pl.col(m["fecha_nacimiento"])
        .map_elements(
            lambda v: formatear_fecha_nacimiento(v, orden),
            return_dtype=pl.Utf8,
        )
        .alias(COL_FECHA_NACIMIENTO)
    )


_ALIAS_FUENTE_PERIODO_ACTUAL = (
    "cod periodo",
    "codigo periodo",
    "cod_periodo",
    "ultimo periodo inscrito",
    "periodo ultima matricula",
    "cod pensum",
    "codigo pensum",
    "cod_pensum",
)


def _expr_periodo_actual(df: pl.DataFrame, m: dict[str, str], nr: dict[str, str]) -> pl.Expr:
    """COD_PERIODO gana sobre COD_PENSUM; formatea YYYY-N o deja vacío."""
    candidatos: list[pl.Expr] = []
    vistos: set[str] = set()
    for alias in _ALIAS_FUENTE_PERIODO_ACTUAL:
        col = nr.get(normalizar_encabezado(alias))
        if col and col not in vistos:
            vistos.add(col)
            candidatos.append(
                pl.col(col).map_elements(formatear_periodo_cod, return_dtype=pl.Utf8)
            )
    if "periodo_actual" in m and m["periodo_actual"] not in vistos:
        candidatos.append(
            pl.col(m["periodo_actual"]).map_elements(formatear_periodo_cod, return_dtype=pl.Utf8)
        )
    if not candidatos:
        return pl.lit(None).cast(pl.Utf8).alias(COL_PERIODO_ACTUAL)
    expr = candidatos[0]
    for extra in candidatos[1:]:
        expr = pl.coalesce(expr, extra)
    return expr.alias(COL_PERIODO_ACTUAL)

def renombrar_y_filtrar(
    df: pl.DataFrame,
    *,
    formato_fecha_nacimiento: str = FORMATO_FECHA_DMY,
) -> pl.DataFrame:
    cols = list(df.columns)
    m = construir_mapa_columnas(cols)
    nr = _mapa_norm_a_real(cols)

    if "identificacion" not in m and "nombre_estudiante" not in m and not (
        "nombres" in nr and "apellidos" in nr
    ):
        raise ValueError(
            "No se encontró columna de identificación ni de nombre. "
            f"Columnas del archivo: {cols}. "
            "Revisa la hoja usada o amplía la detección en consolidado.core.archivos."
        )

    exprs: list[pl.Expr] = [
        pl.col(m["identificacion"]).alias("Identificación")
        if "identificacion" in m
        else pl.lit(None).cast(pl.Utf8).alias("Identificación")
    ]
    exprs.append(_expr_nombre_completo(df, m, nr))
    exprs.append(_expr_telefono_celular(df, m, nr))
    exprs.append(_expr_fecha_nacimiento(df, m, formato_fecha_nacimiento))

    for canon, salida in [
        ("programa", "Programa"),
        ("correo_institucional", "Correo institucional"),
        ("correo_personal", "Correo personal"),
        ("periodo_ingreso", "Periodo ingreso"),
        ("pensum", "Pensum"),
        ("reintegros", "Reintegros"),
        ("lugar_nacimiento", "Lugar de nacimiento"),
        ("lugar_residencia", "Lugar de residencia"),
    ]:
        exprs.append(
            pl.col(m[canon]).alias(salida) if canon in m else pl.lit(None).alias(salida)
        )

    exprs.append(_expr_periodo_actual(df, m, nr))

    exprs.append(_expr_funcionario_beca(df, m, nr))
    exprs.append(_expr_tipo_beca(df, m, nr))
    exprs.append(_expr_total_beca(df, m, nr))
    for col_prio in COLUMNAS_PRIORIZADO:
        exprs.append(pl.lit(None).alias(col_prio))

    return df.select(exprs)

def formatear_dataframe_salida(df: pl.DataFrame) -> pl.DataFrame:
    exprs: list[pl.Expr] = []
    for col in df.columns:
        if col in ("Identificación", "Periodo ingreso", "Reintegros"):
            exprs.append(
                pl.col(col).map_elements(_entero_o_texto, return_dtype=pl.String).alias(col)
            )
        elif col == COL_PERIODO_ACTUAL:
            exprs.append(
                pl.col(col)
                .map_elements(formatear_periodo_cod, return_dtype=pl.Utf8)
                .alias(col)
            )
        elif col == COL_TELEFONO_CELULAR:
            exprs.append(
                pl.col(col)
                .map_elements(lambda v: normalizar_telefono_celda(v), return_dtype=pl.Utf8)
                .alias(col)
            )
        elif col == COL_FECHA_NACIMIENTO:
            exprs.append(
                pl.col(col)
                .map_elements(
                    lambda v: formatear_fecha_nacimiento(v, FORMATO_FECHA_DMY),
                    return_dtype=pl.Utf8,
                )
                .alias(col)
            )
        else:
            exprs.append(pl.col(col))
    return df.select(exprs)

def alinear_dataframe_salida(df: pl.DataFrame, columnas: list[str]) -> pl.DataFrame:
    faltantes = [c for c in columnas if c not in df.columns]
    if faltantes:
        df = df.with_columns(pl.lit(None).alias(c) for c in faltantes)
    return df.select(columnas)

def _buscar_columna_por_aliases(columns: list[str], aliases: list[str]) -> str | None:
    nr = _mapa_norm_a_real(columns)
    for alias in aliases:
        key = normalizar_encabezado(alias)
        if key in nr:
            return nr[key]
    return None

