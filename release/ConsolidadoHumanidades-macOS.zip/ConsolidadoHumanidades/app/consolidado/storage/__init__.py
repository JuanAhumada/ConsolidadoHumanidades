"""
Persistencia del consolidado.

db.py es el schema y las versiones. El resto son tablas/marcas globales
(priorizados propios, alertas propias, contactados, usuarios, historial).
Periodo actual del estudiante: periodos.py (no confundir con periodo de versión).
"""

from consolidado.storage.priorizados import *  # noqa: F403
from consolidado.storage.alertas_propias import (  # noqa: F401
    agregar_alerta_propia,
    cargar_alertas_propias,
    guardar_alertas_propias,
    quitar_alerta_propia,
)
from consolidado.storage.alertas_fuente import (  # noqa: F401
    aplicar_alertas_descartadas,
    descartar_alerta_fuente,
    listar_alertas_fuente,
)
from consolidado.storage.usuarios import (  # noqa: F401
    asegurar_admin_inicial,
    autenticar,
    crear_usuario,
    listar_usuarios,
)
from consolidado.storage.contactados import (  # noqa: F401
    cargar_ids_contactados,
    es_contactado,
    estadisticas_atenciones,
    listar_contactados,
    marcar_contactado,
)
from consolidado.storage.graduacion import (  # noqa: F401
    cargar_marcas_gradua,
    marcar_gradua,
    obtener_marca_gradua,
)
from consolidado.storage.notas import (  # noqa: F401
    agregar_nota,
    listar_notas,
    quitar_nota,
    resumen_notas,
)
from consolidado.storage.db import (  # noqa: F401
    buscar_estudiantes,
    buscar_estudiantes_version,
    contar_estudiantes_distintos,
    contar_versiones,
    cargar_dataframe_version,
    guardar_version,
    listar_versiones,
    nombre_excel_version,
    obtener_fila_estudiante,
    obtener_version,
    periodo_desde_fecha,
    ruta_base_datos,
    ultima_version,
    ultima_version_por_id,
    vaciar_versiones,
)
from consolidado.storage.modificaciones import (  # noqa: F401
    comparar_versiones,
    listar_modificaciones,
    registrar_modificacion,
)
from consolidado.storage.periodos import (  # noqa: F401
    mapa_periodos_desde_fuentes,
    sincronizar_periodo_actual_ultima_version,
)
from consolidado.storage.versiones import (  # noqa: F401
    asegurar_excel_version,
    asegurar_semilla_si_vacia,
    exportar_excel_version,
    importar_excel_como_version,
    leer_dataframe_desde_excel_consolidado,
    sembrar_version_inicial,
)
